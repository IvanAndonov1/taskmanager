package com.IvanAndonov1.taskmanager.model;

public enum Role {
    USER
}
